


import HomeLayout from './home/layout'
import MainHome from './home/page'


export default function Home() {
  return (
    <>
    
    <HomeLayout>
      <MainHome />
    </HomeLayout>
    </>
    
  )
}
