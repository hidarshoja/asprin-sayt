export default function DashboardLayout({children}) {
    return(
        <div>
            
              {children}
        </div>
    )
  }