import React from 'react'

const Service = () => {
  return (
    <div>
      Service Service
    </div>
  )
}

export default Service
